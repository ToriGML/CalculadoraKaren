import java.util.Scanner;

public class Main {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        menu();
    }

    private static void menu() {
        System.out.print("|-------------------------------------|" +
                "\n|  Informe qual operação você deseja: " +
                "\n|  1 - Adição" +
                "\n|  2 - Subtração" +
                "\n|  3 - Multiplicação" +
                "\n|  4 - Divisão" +
                "\n|  5 - Potência" +
                "\n|  6 - Raíz quadrada" +
                "\n|  7 - Finalizar Sistema" +
                "\n|--> ");
        switch(sc.nextInt()){
            case 1:
                System.out.println("|  O resultado da adição foi: " + Operacao.adicao(numero(), numero()) + "\n|");
                break;
            case 2:
                System.out.println("|  O resultado da subtração foi: " + Operacao.subtracao(numero(), numero()) + "\n|");
                break;
            case 3:
                System.out.println("|  O resultado da multiplicação foi: " + Operacao.multiplicacao(numero(), numero()) + "\n|");
                break;
            case 4:
                System.out.println("|  O resultado da divisão foi: " + Operacao.divisao(numero(), numero()) + "\n|");
                break;
            case 5:
                System.out.println("|  O resultado da potência foi: " + Operacao.potencia(numero(), numero()) + "\n|");
                break;
            case 6:
                System.out.print("|  Informe a raíz: ");
                double raiz = sc.nextDouble();
                System.out.println("|  O resultado da raíz quadrada foi: " + Operacao.raiz(raiz) + "\n|");
                break;
            case 7:
                System.out.print("|-------------------------------------|");
                System.exit(0);
        }
        menu();
    }
    private static double numero(){
        System.out.print("|  Informe o número que deseja: ");
        double num = sc.nextDouble();
        return num;
    }
}
